# AI-Powered Fake Job and Internship Detection (NLP + Deep Learning)

Classifies a job/internship advertisement as **Likely Legitimate** or **Potentially Fraudulent** using the EMSCAD dataset.
It integrates NLP preprocessing, classical ML baselines, ANN / LSTM / BiLSTM / 1D-CNN models, evaluation, and a Streamlit app.

> The app output is an **AI-generated risk estimate**, not proof of fraud or legitimacy.
> **No results are included in this repository.** Every number you see comes from models you train on your own copy of the data.

## 1. Project structure
```
fake-job-detection/
├── data/raw/            <- put fake_job_postings.csv here (not committed)
├── data/processed/      <- cached train/val/test splits (generated)
├── notebooks/           01..07  (exploration -> preprocessing -> baselines -> ANN -> LSTM -> CNN -> evaluation)
├── src/
│   ├── config.py        paths, seed, label mapping (0 legit / 1 fraud), hyper-parameters
│   ├── data.py          loading, de-duplication, stratified 70/15/15 split
│   ├── preprocessing.py two cleaning pipelines (ML and NN) + Vocabulary class
│   ├── models.py        baselines, ANN, LSTM, BiLSTM, CNN, Word2Vec, training/tuning
│   ├── evaluate.py      metrics, threshold selection, plots, model comparison, model selection
│   ├── explain.py       rule-based red flags + linear-model term contributions
│   ├── predict.py       reusable prediction function (loads saved artefacts only)
│   └── train.py         one-command training
├── app.py               Streamlit app (Home, Job Analysis, Model Performance, About)
├── models/              saved models, vectorisers, vocab.json, metrics.json (generated)
├── reports/             figures, model_comparison.md, dataset_info.json (generated) + report/viva docs
├── tests/               unit tests for preprocessing
└── requirements.txt
```

## 2. Setup
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m pytest -q tests          # optional sanity check
```
Python 3.10-3.12 is recommended for TensorFlow. NLTK data (stopwords, wordnet) downloads automatically on first use.

## 3. Get the dataset
Download `fake_job_postings.csv` from Kaggle: <https://www.kaggle.com/datasets/shivamb/real-or-fake-fake-jobposting-prediction>
(a free account is required) and save it as `data/raw/fake_job_postings.csv`.

Or with the Kaggle API (`~/.kaggle/kaggle.json` configured):
```bash
pip install kaggle
kaggle datasets download -d shivamb/real-or-fake-fake-jobposting-prediction -p data/raw --unzip
```

## 4. Train
**Option A - notebooks (recommended for learning and for your submission).** Run them in order, 01 -> 07.
Notebook 07 selects the final model and writes the files the app needs.

**Option B - one command:**
```bash
python -m src.train                  # everything, with a small hyper-parameter search
python -m src.train --models logreg_tfidf nb_bow ann_tfidf lstm cnn      # subset
python -m src.train --no-tune        # faster
python -m src.train --quick          # 2 epochs, only to test that the code runs (results are meaningless)
```
Training time depends on hardware. On a CPU, the LSTM/BiLSTM are the slowest; use Google Colab with a GPU if needed.

### Google Colab
1. Upload the project folder (or clone your repo) and the CSV; `%cd fake-job-detection`.
2. `!pip install -q -r requirements.txt` (TensorFlow is preinstalled in Colab; you may skip it by removing that line).
3. Put the CSV at `data/raw/fake_job_postings.csv` and run the notebooks or `!python -m src.train`.
4. Download the `models/` and `reports/` folders afterwards to run the Streamlit app locally.

## 5. Run the web app
```bash
streamlit run app.py
```
The app **never trains**. It loads `models/final_model.json` (written by training/notebook 07) and the saved metrics and figures.

## 6. Use the prediction function directly
```python
from src.predict import predict_job
r = predict_job("Paste the advertisement text here...", title="Data Entry Intern", company="ACME")
print(r["label"], r["score"]); print(r["red_flags"])
```
Returned keys: `label`, `label_id`, `score`, `threshold`, `explanation`, `red_flags`, `logreg_terms`, `disclaimer`.

## 7. Design decisions you should be able to explain
- **Fraudulent = positive class (1)** everywhere; one mapping in `src/config.py`.
- **Leakage prevention:** duplicates removed *before* splitting; stratified 70/15/15 split with seed 42; TF-IDF/BoW vectorisers, vocabulary and Word2Vec are fitted on **train only**; hyper-parameters *and* thresholds are chosen on **validation**; the test set is used only for reporting; the final model is selected on validation PR-AUC.
- **Imbalance:** class weights (balanced) for LR and neural nets; PR-AUC, recall and F1 reported besides accuracy; threshold tuning.
- **Two preprocessing pipelines:** ML (stop-words removed but negations kept, lemmatised) vs NN (light cleaning, word order kept). URLs/e-mails/phones become tokens and salary numbers are kept.
- **Text-only input:** all fields are merged into one string, so the app can score exactly what a user pastes. Structured flags (logo, questions) and missing-value indicators are *not* used - a documented trade-off.
- **Explanations are separated:** (a) rule-based red flags are heuristics independent of the model; (b) term contributions come from the *logistic-regression baseline only*. Neither is presented as the cause of an LSTM/CNN prediction.
- **Probability caveat:** the score is not calibrated. Notebook 07 includes a calibration check.
- **Security:** Keras models use `.keras`, vocabulary uses JSON. sklearn artefacts use `joblib` (pickle-based): **only load files you trained yourself**, never files from untrusted sources.

## 8. Troubleshooting
| Problem | Fix |
|---|---|
| `FileNotFoundError ... fake_job_postings.csv` | Put the CSV in `data/raw/` (see section 3). |
| `LookupError` (NLTK) | `python -c "import nltk; nltk.download('stopwords'); nltk.download('wordnet')"` |
| TensorFlow will not install | Use Python 3.10-3.12, or use Colab. |
| `Run the baseline step first` | Train the baselines (notebook 03 or `python -m src.train`) before the ANN. |
| App says no trained models | Run training / notebook 07 so `models/final_model.json` exists. |
| Out of memory in LSTM | Lower `MAX_LEN` or batch size; use Colab GPU. |
| Results differ slightly between runs | Neural nets are only approximately reproducible across hardware; seeds are fixed (42). |

## 9. Deliverables checklist
- [ ] Run notebooks 01-07 on the real data
- [ ] Fill `reports/REPORT.md` using your actual numbers (`reports/model_comparison.md`, figures in `reports/figures/`)
- [ ] Take app screenshots for the report
- [ ] Review `reports/PRESENTATION.md` and `reports/VIVA.md`
