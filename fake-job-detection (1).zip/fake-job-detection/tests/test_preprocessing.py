import numpy as np
from src.preprocessing import Vocabulary, clean_for_ml, clean_for_nn, normalize_text, tokenize
from src.explain import find_red_flags


def test_negation_and_stopwords():
    out = clean_for_ml("You do not need the experience")
    assert "not" in out.split() and "the" not in out.split()


def test_url_email_phone_tokens_and_amounts():
    t = normalize_text("Visit https://x.com or mail bob@gmail.com or call 555-123-4567. Earn $5000 weekly")
    for tok in ["urltoken", "freeemailtoken", "phonetoken", "dollar", "5000"]:
        assert tok in tokenize(t)


def test_nn_pipeline_keeps_stopwords():
    assert "the" in clean_for_nn("the job").split()


def test_vocab_encode_pads_and_oov():
    v = Vocabulary.build([["a", "a", "b", "b"]], max_size=10, min_freq=2)
    ids = v.encode(["a", "zzz"], 5)
    assert len(ids) == 5 and ids[1] == 1 and ids[2:] == [0, 0, 0]


def test_red_flags():
    names = [f["flag"] for f in find_red_flags("Pay a registration fee and contact us on WhatsApp", min_words=1)]
    assert "Upfront payment requested" in names and "Contact through a messaging app" in names
