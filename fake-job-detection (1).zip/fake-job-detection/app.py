"""Streamlit web app. It only LOADS saved artefacts and results - it never trains a model.
Run:  streamlit run app.py"""
import json
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
MODELS, FIGS, REPORTS = ROOT / "models", ROOT / "reports" / "figures", ROOT / "reports"

st.set_page_config(page_title="Fake Job Detector", page_icon="🛡️", layout="wide")

st.markdown("""
<style>
:root { --navy:#0B2545; --teal:#13A89E; --soft:#EEF4F8; }
.block-container { padding-top: 2rem; max-width: 1150px; }
h1, h2, h3 { color: var(--navy); }
.hero { background: linear-gradient(120deg, #0B2545 0%, #134074 60%, #13A89E 100%); color: white;
        padding: 2.2rem 2rem; border-radius: 16px; margin-bottom: 1.5rem; }
.hero h1 { color: white; margin: 0 0 .4rem 0; font-size: 2rem; }
.hero p { margin: 0; opacity: .92; font-size: 1.05rem; }
.card { background: var(--soft); border-radius: 12px; padding: 1.1rem 1.2rem; border-left: 5px solid var(--teal); height: 100%; }
.card h4 { margin: 0 0 .35rem 0; color: var(--navy); }
.result { border-radius: 14px; padding: 1.3rem 1.5rem; margin: 1rem 0; color: #111; }
.result.ok { background: #E6F6EE; border: 2px solid #2E9E6B; }
.result.bad { background: #FDECEC; border: 2px solid #D64545; }
.result h2 { margin: 0 0 .2rem 0; color: #111; }
.flag { background:#FFF7E0; border-left:4px solid #E0A800; padding:.6rem .9rem; border-radius:8px; margin-bottom:.5rem; color:#222; }
.disclaimer { background:#FFF4E5; border:1px solid #F0C27B; padding:.8rem 1rem; border-radius:10px; color:#4a3500; font-size:.92rem; }
@media (prefers-color-scheme: dark) { .card { background:#16263b; color:#e8eef5; } .card h4 { color:#8fe3db; } h1,h2,h3 { color:#e8eef5; } }
</style>""", unsafe_allow_html=True)

DISCLAIMER = ("⚠️ **Disclaimer:** this tool produces an **AI-generated risk estimate**, not proof of fraud or legitimacy. "
              "It was trained on an older public dataset (EMSCAD) and can be wrong in both directions. "
              "Always verify the employer independently and never pay money to get a job.")


def load_json(path):
    return json.loads(path.read_text()) if path.exists() else None


@st.cache_resource(show_spinner="Loading trained model…")
def get_predictor():
    from src.predict import FakeJobPredictor
    return FakeJobPredictor()


def need_training():
    st.warning("No trained models found. Train them first (see README): `python -m src.train`, "
               "or run the notebooks in order.")


# ------------------------------------------------------------------ pages
def page_home():
    st.markdown('<div class="hero"><h1>🛡️ AI-Powered Fake Job & Internship Detector</h1>'
                '<p>NLP + Deep Learning to help students and job seekers spot suspicious postings.</p></div>', unsafe_allow_html=True)
    st.subheader("The problem")
    st.write("Online recruitment fraud targets students and fresh graduates with fake offers that ask for fees, "
             "personal data or unpaid work. Spotting them by hand is hard, especially for first-time job seekers.")
    st.subheader("How it works")
    c = st.columns(4)
    steps = [("1. Clean text", "Normalise the posting; keep URLs, amounts and negations as signals."),
             ("2. Represent", "TF-IDF / Bag-of-Words for classical models; integer sequences + embeddings for neural nets."),
             ("3. Classify", "Logistic Regression, Naive Bayes, ANN, LSTM, BiLSTM and 1D CNN were trained and compared."),
             ("4. Report", "A risk score from the model, plus separate rule-based warning signs.")]
    for col, (t, d) in zip(c, steps):
        col.markdown(f'<div class="card"><h4>{t}</h4>{d}</div>', unsafe_allow_html=True)
    st.write("")
    final = load_json(MODELS / "final_model.json")
    if final:
        st.info(f"Current model in use: **{final['display_name']}** (selected on validation PR-AUC).")
    st.markdown(f'<div class="disclaimer">{DISCLAIMER}</div>', unsafe_allow_html=True)


def page_analysis():
    st.title("🔍 Job Analysis")
    if not (MODELS / "final_model.json").exists():
        return need_training()
    st.write("Paste a job or internship advertisement. Optional fields can add context.")
    desc = st.text_area("Job / internship advertisement *", height=240, placeholder="Paste the full posting text here…")
    c1, c2, c3 = st.columns(3)
    title = c1.text_input("Job title (optional)"); company = c2.text_input("Company name (optional)")
    location = c3.text_input("Location (optional)")
    c4, c5 = st.columns(2)
    salary = c4.text_input("Salary (optional)")
    emp = c5.selectbox("Employment type (optional)", ["", "Full-time", "Part-time", "Contract", "Temporary", "Internship", "Other"])
    if st.button("Analyze", type="primary"):
        try:
            with st.spinner("Analysing…"):
                r = get_predictor().predict(desc, title=title, company=company, location=location, salary=salary, employment_type=emp)
        except ValueError as e:
            st.error(str(e)); return
        bad = r["label_id"] == 1
        icon = "🚩" if bad else "✅"
        st.markdown(f'<div class="result {"bad" if bad else "ok"}"><h2>{icon} {r["label"]}</h2>'
                    f'<div>Model score for the fraudulent class: <b>{r["score"]:.0%}</b> '
                    f'(decision threshold {r["threshold"]:.0%})</div></div>', unsafe_allow_html=True)
        st.progress(min(max(r["score"], 0.0), 1.0))
        st.caption("This score is the model's output, **not** a verified or calibrated probability of fraud.")
        st.write(r["explanation"])

        st.subheader("Rule-based warning signs")
        st.caption("Simple pattern checks for common scam wording. They are independent of the AI model and do not explain its score.")
        if r["red_flags"]:
            for f in r["red_flags"]:
                st.markdown(f'<div class="flag"><b>{f["flag"]}</b> — found: <i>{f["matched_text"]}</i><br>{f["why"]}</div>', unsafe_allow_html=True)
        else:
            st.success("No common scam patterns matched. That does not guarantee the job is genuine.")

        if r["logreg_terms"]:
            with st.expander("Terms that influenced the Logistic Regression baseline (explains that model only)"):
                a, b = st.columns(2)
                a.markdown("**Towards fraudulent**")
                a.write(pd.DataFrame(r["logreg_terms"]["towards_fraud"], columns=["term", "contribution"]) if r["logreg_terms"]["towards_fraud"] else "none")
                b.markdown("**Towards legitimate**")
                b.write(pd.DataFrame(r["logreg_terms"]["towards_legitimate"], columns=["term", "contribution"]) if r["logreg_terms"]["towards_legitimate"] else "none")
        with st.expander("Limitations of this analysis"):
            st.markdown("- Trained on EMSCAD (postings from about 2012–2014); modern scams use new wording and channels.\n"
                        "- Fraud is rare in the training data, so scores are less reliable than they may look.\n"
                        "- Text only: logos, company websites, recruiter identity and payment requests made later are not seen.")
        st.markdown(f'<div class="disclaimer">{DISCLAIMER}</div>', unsafe_allow_html=True)
    st.write("")
    st.markdown("**Safety checklist:** search the company independently · check the recruiter's e-mail domain · never pay fees · never share bank or ID details early.")


def page_performance():
    st.title("📊 Model Performance")
    results = load_json(MODELS / "metrics.json")
    if not results:
        return need_training()
    final = load_json(MODELS / "final_model.json")
    st.write("All models were evaluated on the **same held-out test set**. Fraudulent = positive class. "
             "Each model's decision threshold was chosen on the validation set only.")
    rows = [{"Model": r["display_name"], **{k: r["test"][k] for k in ["accuracy", "precision", "recall", "f1", "roc_auc", "pr_auc"]},
             "FP": r["test"]["fp"], "FN": r["test"]["fn"], "threshold": r["test"]["threshold"]} for r in results]
    df = pd.DataFrame(rows).set_index("Model")
    st.dataframe(df.style.format({c: "{:.3f}" for c in df.columns if c not in ("FP", "FN")}), width="stretch")
    if final:
        st.success(f"Selected model: **{final['display_name']}** — chosen by {final['selection_criterion']}. "
                   "Practical considerations (speed, size, interpretability) should also inform the final choice.")
    st.caption("With few fraudulent examples in the test set, differences between models can be within statistical noise.")

    t1, t2, t3, t4 = st.tabs(["Metric chart", "Confusion matrices", "Training curves", "Dataset"])
    with t1:
        metric = st.selectbox("Metric", ["recall", "precision", "f1", "pr_auc", "roc_auc", "accuracy"], index=2)
        st.bar_chart(df[metric])
        c1, c2 = st.columns(2)
        for col, f in zip((c1, c2), ("roc_comparison.png", "pr_comparison.png")):
            if (FIGS / f).exists():
                col.image(str(FIGS / f), width="stretch")
        st.markdown("**False positive** = a genuine job flagged as suspicious (lost opportunity, unfair to employers). "
                    "**False negative** = a fake job missed (the costlier error for job seekers, so recall on fraud matters).")
    with t2:
        cols = st.columns(3)
        for i, r in enumerate(results):
            p = FIGS / f"cm_{r['name']}.png"
            if p.exists():
                cols[i % 3].image(str(p), width="stretch")
    with t3:
        shown = False
        for r in results:
            p = FIGS / f"history_{r['name']}.png"
            if p.exists():
                st.image(str(p), caption=r["display_name"], width="stretch"); shown = True
        if not shown:
            st.info("No neural-network training curves saved yet.")
    with t4:
        info = load_json(REPORTS / "dataset_info.json")
        if info:
            names = {0: "Legitimate", 1: "Fraudulent"}
            tab = pd.DataFrame({s: {names[int(k)]: v for k, v in info[f"{s}_class_counts"].items()} for s in ("train", "val", "test")})
            st.write(f"Raw dataset shape: {info['raw_shape']} · duplicates removed: {info['dropped_duplicates']} · label conflicts removed: {info['dropped_label_conflicts']}")
            st.bar_chart(tab.T)
            st.dataframe(tab)


def page_about():
    st.title("ℹ️ About the Project")
    st.subheader("Dataset")
    st.write("Employment Scam Aegean Dataset (EMSCAD), via the Kaggle 'Real or Fake Job Posting Prediction' dataset. "
             "Labels: 0 = legitimate, 1 = fraudulent. The dataset is imbalanced and comes from roughly 2012–2014.")
    st.subheader("NLP techniques")
    st.write("Normalisation, regex tokenisation, stop-word removal (negations kept), lemmatisation (stemming compared), "
             "Bag-of-Words, TF-IDF, n-grams, vocabulary building, integer encoding and padding, trainable embeddings, Word2Vec initialisation.")
    st.subheader("Models")
    st.write("Logistic Regression and Multinomial Naive Bayes baselines; feed-forward ANN (ReLU, sigmoid, dropout, Adam, binary cross-entropy); "
             "LSTM and BiLSTM; 1D CNN; LSTM initialised with Word2Vec. Class imbalance handled with class weights, and thresholds tuned on validation data.")
    cfg = load_json(MODELS / "preprocess_config.json")
    if cfg:
        with st.expander("Preprocessing configuration used in training"):
            st.json(cfg)
    st.subheader("Limitations & responsible use")
    st.markdown("- Output is a **risk estimate**, never a verdict. Do not use it to accuse a company or individual.\n"
                "- Historical data: new scam styles may be missed.\n"
                "- Probabilities are not calibrated against real-world fraud rates.\n"
                "- Rule-based warning signs and model scores are separate; neither proves fraud.\n"
                "- Use it alongside your own checks: company website, reviews, recruiter identity, and never paying fees.")
    st.markdown(f'<div class="disclaimer">{DISCLAIMER}</div>', unsafe_allow_html=True)


PAGES = {"🏠 Home": page_home, "🔍 Job Analysis": page_analysis, "📊 Model Performance": page_performance, "ℹ️ About Project": page_about}
choice = st.sidebar.radio("Navigate", list(PAGES))
st.sidebar.markdown("---"); st.sidebar.caption("AI-generated risk estimate · not proof of fraud")
PAGES[choice]()
