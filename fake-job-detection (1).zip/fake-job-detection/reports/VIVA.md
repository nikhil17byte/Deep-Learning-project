# Viva questions and answers
*(Answers are conceptual. When asked about your results, quote your own numbers.)*

## NLP
**1. Why preprocess text?** Raw text is noisy (case, HTML, punctuation, inflections). Normalising reduces vocabulary size and variance so models learn patterns instead of surface differences.
**2. Stemming vs lemmatisation?** Stemming chops suffixes by rules (fast, may give non-words: "companies" -> "compani"). Lemmatisation uses a dictionary and part of speech to return real base forms ("better" -> "good" as an adjective). Lemmatisation is cleaner; stemming shrinks vocabulary more.
**3. Why keep negations when removing stop-words?** "No experience required" and "experience required" differ in meaning; standard lists contain "no/not/nor", so we remove them from the stop list.
**4. Why replace URLs/e-mails with tokens and keep numbers?** Their *presence* and salary amounts are informative scam signals, while the exact URL is rarely seen twice.
**5. Bag-of-Words vs TF-IDF?** BoW counts words. TF-IDF multiplies term frequency by inverse document frequency, down-weighting words common across all documents and up-weighting distinctive ones.
**6. What are n-grams?** Sequences of n consecutive words (e.g. "registration fee"); they capture short phrases that single words miss, at the cost of larger feature spaces.
**7. What is an embedding?** A dense, low-dimensional learned vector for each token; similar words get nearby vectors. Unlike one-hot vectors, embeddings generalise and are compact.
**8. How does Word2Vec work?** Skip-gram predicts surrounding words from a centre word (CBOW does the reverse), learning vectors from co-occurrence without labels. We train it on training text only to avoid leakage.
**9. Why pad sequences? What does masking do?** Batches need equal length; zeros fill short texts. Masking tells the LSTM to ignore padding.
**10. What is OOV and how do we handle it?** Words not in the training vocabulary map to a special `<oov>` id.

## ANN, backpropagation, activations, loss
**11. Explain the ANN's structure.** Input TF-IDF vector -> hidden Dense layers (ReLU) -> dropout -> one sigmoid output giving a fraud score. Each layer computes z = Wx + b then applies an activation.
**12. What are weights and biases?** Weights scale inputs; biases shift the pre-activation. Both are learned parameters.
**13. Forward propagation?** Passing inputs through layers to produce an output and then a loss.
**14. Backpropagation?** Applying the chain rule backwards from the loss to compute the gradient of the loss with respect to each weight; the optimiser then updates the weights. Notebook 04 does this by hand and verifies it numerically.
**15. Why ReLU in hidden layers?** max(0, z) is cheap, avoids saturation for positive inputs (less vanishing gradient) and gives sparse activations; a risk is "dead" units.
**16. Why sigmoid at the output?** It maps to (0,1), interpretable as a score for the positive class in binary classification.
**17. Binary cross-entropy?** L = -[y log p + (1-y) log(1-p)]; it heavily penalises confident wrong predictions and is the negative log-likelihood of a Bernoulli model.
**18. Adam optimiser?** Gradient descent with per-parameter adaptive learning rates using running averages of gradients and squared gradients (momentum + RMSprop ideas).
**19. Why is the sigmoid + BCE gradient simple?** dL/dz = p - y, which is what the NumPy demo uses.

## CNN and LSTM
**20. How does a 1D CNN classify text?** Filters of width k slide over the embedding sequence, detecting local patterns; global max-pooling keeps the strongest activation per filter; dense layers classify.
**21. Kernel size, stride, padding?** Kernel = window width in words; stride = step size; "same" padding keeps the length, "valid" shortens it to floor((L-k)/s)+1.
**22. How does an LSTM work?** It keeps a cell state controlled by input, forget and output gates, which lets it retain information over long sequences and mitigates vanishing gradients seen in plain RNNs.
**23. BiLSTM vs LSTM?** The BiLSTM reads forwards and backwards, giving context from both sides; it costs about twice the computation.
**24. CNN vs LSTM for this task?** CNNs are faster and good at local phrases; LSTMs model order and longer dependencies. Which is better here must be decided from validation/test results, not assumed.

## Imbalance, generalisation, evaluation
**25. Why is accuracy misleading here?** With few fraud examples, predicting "legitimate" always yields high accuracy and zero recall on fraud.
**26. How did you handle imbalance?** Class weights (balanced), PR-AUC/recall/F1 as key metrics, threshold tuning on validation, stratified splits. Resampling (e.g. SMOTE) must be applied to training data only, and was not needed here.
**27. Precision, recall, F1?** Precision = TP/(TP+FP), recall = TP/(TP+FN), F1 = harmonic mean. For fraud, recall measures how many scams we catch; precision measures how many flags are correct.
**28. ROC-AUC vs PR-AUC?** ROC-AUC can look optimistic with rare positives since it includes many true negatives; PR-AUC focuses on the positive class.
**29. False positive vs false negative here?** FP: a real job is flagged (lost opportunity). FN: a scam is missed (harm). We emphasise recall but must watch precision.
**30. Overfitting vs underfitting; how to detect and fix?** Overfitting: low training loss, high/rising validation loss -> dropout, L2, early stopping, smaller model, more data. Underfitting: both losses high -> bigger model, better features, longer training.
**31. What is data leakage and how did you avoid it?** Information from validation/test influencing training. We deduplicated before splitting, fitted vectorisers/vocabulary/Word2Vec on train only, tuned on validation, and touched test only for reporting.
**32. Why choose the model on validation, not test?** Selecting on test would make the test score optimistic. The test set is the final unbiased check.
**33. Is the output a probability of fraud?** No. It is an uncalibrated model score; we show a calibration check and label it a risk estimate.
**34. What does dropout do?** Randomly zeros units during training so the network cannot rely on specific neurons, reducing overfitting.
**35. What is the role of the threshold?** It converts the score into a class. 0.5 is arbitrary under imbalance, so we choose it on validation (max F1) and report it.

## Deployment and responsibility
**36. How is the model deployed?** Training saves models, vectorisers/vocabulary and config; `src/predict.py` loads them and applies identical preprocessing; Streamlit calls it. The app never retrains.
**37. Why separate red flags from the model's explanation?** Rule-based patterns are independent heuristics; claiming they caused the model's prediction would be unsupported. Only the logistic regression gives a direct linear explanation.
**38. Main limitations?** Old dataset (about 2012-2014), imbalance, text-only inputs, uncalibrated scores, possible artefacts, English only.
**39. How could it be misused and how do you mitigate?** Falsely accusing employers or giving false reassurance. Mitigation: clear disclaimers, risk-estimate wording, advice to verify independently.
**40. How would you improve it?** Newer data, transformers (BERT), calibration, SHAP/LIME explanations, company verification signals, drift monitoring.
