# AI-Powered Fake Job and Internship Detection System Using NLP and Deep Learning
**Project report template.** Text that is general (background, methods, definitions) is written for you.
Anything in **«FILL: ...»** must come from *your own* runs; do not invent numbers. Delete this note before submitting.

---
## 1. Abstract
Online recruitment fraud harms students and fresh graduates through fake offers that seek fees, personal data or free labour. This project builds an end-to-end system that estimates whether a job or internship advertisement resembles fraudulent postings, using the Employment Scam Aegean Dataset (EMSCAD). Text is preprocessed with two NLP pipelines and represented with Bag-of-Words, TF-IDF, n-grams, integer sequences and word embeddings. Logistic Regression and Multinomial Naive Bayes baselines are compared with a feed-forward ANN, LSTM, BiLSTM, 1D CNN and a Word2Vec-initialised LSTM. All models are evaluated on one held-out test set with precision, recall, F1, ROC-AUC and PR-AUC, treating fraudulent postings as the positive class. «FILL: one or two sentences naming the selected model and its test recall/precision/PR-AUC from your results.» A Streamlit application exposes the selected model with a clear disclaimer that outputs are risk estimates, not proof.

## 2. Introduction
Job portals make it easy to reach employers, but also easy for scammers to reach applicants. Fraudulent advertisements often contain recognisable linguistic patterns (requests for upfront payment, vague duties, unrealistic earnings), which makes the task suitable for text classification. This work combines classical NLP with deep learning in a single application and evaluates the approaches honestly under class imbalance.

## 3. Problem statement
Given the text of a job or internship advertisement, estimate the likelihood that it belongs to the fraudulent class according to patterns learned from a labelled dataset, and present the result with appropriate caveats.

## 4. Objectives
1. Explore and preprocess EMSCAD without data leakage.
2. Implement NLP techniques: normalisation, tokenisation, stop-word removal, stemming/lemmatisation, BoW, TF-IDF, n-grams, vocabulary/encoding, embeddings, Word2Vec.
3. Train and compare classical ML and neural models (ANN, LSTM, BiLSTM, CNN).
4. Evaluate with metrics suited to imbalanced data and discuss false positives/negatives.
5. Deploy the selected model in a web application that is transparent about its limits.

## 5. Literature review
*(Summarise in your own words; verify every reference below against the original source before citing.)*
- **Dataset and task.** Vidros, Kolias, Kambourakis and Akoglu (2017) introduced EMSCAD and studied automatic detection of online recruitment fraud using text and meta-data features with classical classifiers.
- **Text representations.** TF-IDF weighting (Salton & Buckley, 1988) and Word2Vec embeddings (Mikolov et al., 2013) represent text numerically; embeddings capture similarity from context.
- **Neural architectures.** LSTMs (Hochreiter & Schmidhuber, 1997) model sequences with gated memory; bidirectional RNNs (Schuster & Paliwal, 1997) read in both directions; CNNs for sentence classification (Kim, 2014) detect local n-gram-like patterns.
- **Training.** Backpropagation (Rumelhart, Hinton & Williams, 1986), Adam (Kingma & Ba, 2015), dropout (Srivastava et al., 2014).
- **Evaluation on imbalanced data.** Precision-recall curves are more informative than ROC curves when positives are rare (Saito & Rehmsmeier, 2015).
- «FILL: add 2-4 further papers on fake-job or fraud detection that you actually read.»

## 6. Dataset description
EMSCAD (Kaggle "Real or Fake Job Posting Prediction"), file `fake_job_postings.csv`. Text fields: title, company_profile, description, requirements, benefits; categorical: location, department, salary_range, employment_type, required_experience, required_education, industry, function; binary: telecommuting, has_company_logo, has_questions; target `fraudulent` (0 legitimate, 1 fraudulent).
- Raw shape, class counts, duplicates removed, label conflicts: «FILL from `reports/dataset_info.json` / notebook 01».
- Missing values: «FILL: key findings from notebook 01».
- Class distribution figure: `reports/figures/class_distribution.png`.
- Split sizes (train/val/test) and class counts: «FILL from `reports/dataset_info.json`».
- **Limitations:** postings date from roughly 2012-2014; fraud class is a small minority; labels not independently re-verified; modern scam styles are absent.

## 7. Methodology and system architecture
Pipeline: raw CSV -> merge text fields into one string -> de-duplicate -> stratified 70/15/15 split (seed 42) -> two preprocessing pipelines -> features (TF-IDF / BoW or integer sequences) -> models -> validation-based tuning and threshold selection -> test evaluation -> model selection on validation PR-AUC -> saved artefacts -> prediction module -> Streamlit app.
«FILL: insert an architecture diagram (draw.io or similar).»
**Leakage controls:** de-duplication before the split; vectorisers, vocabulary and Word2Vec fitted on train only; tuning and thresholds on validation only; test set used for reporting only.

## 8. NLP preprocessing
- **Normalisation:** lower-case, HTML removed, URLs/e-mails/phones replaced by tokens (free-mail domains get a distinct token), currency symbols turned into words, numbers kept.
- **Tokenisation:** regex tokeniser (keeps apostrophes and numbers); compared with NLTK `word_tokenize`.
- **Stop-words:** NLTK list minus negations (no, not, nor, never, without ...), only in the ML pipeline.
- **Stemming vs lemmatisation:** Porter stemmer vs WordNet lemmatiser; vocabulary sizes compared in notebook 02 «FILL: your numbers».
- **ML pipeline:** normalise -> tokenise -> stop-words -> lemmatise -> TF-IDF (1-2 grams, min_df=2, max 20,000 features, sublinear tf) or BoW counts.
- **NN pipeline:** normalise -> tokenise (stop-words kept) -> vocabulary (max 20,000, min frequency 2) -> integer ids -> post-padding/truncation to 300 tokens.
- **Embeddings:** trainable Embedding layer (100-d); Word2Vec skip-gram trained on training text for initialisation.
- Include an example: raw posting -> cleaned text -> ids (from notebook 02).

## 9. Model architectures
| Model | Input | Architecture |
|---|---|---|
| Logistic Regression | TF-IDF | linear, L2, class_weight balanced, C tuned |
| Multinomial NB | BoW counts | alpha tuned |
| ANN | TF-IDF (20k) | Dense(ReLU) -> Dropout -> Dense(ReLU) -> Dropout -> Dense(sigmoid); L2; Adam; BCE; class weights |
| LSTM | ids (300) | Embedding(100, masked) -> Dropout -> LSTM -> Dropout -> Dense(sigmoid) |
| BiLSTM | ids | as LSTM with Bidirectional wrapper |
| 1D CNN | ids | Embedding -> Conv1D(128, k=3/5, stride 1, same) -> GlobalMaxPool -> Dropout -> Dense(64, ReLU) -> Dropout -> Dense(sigmoid) |
| LSTM + Word2Vec | ids | LSTM with embedding initialised from Word2Vec |
Parameter counts: «FILL from `model.summary()` or `models/results/*.json`».

## 10. Experimental setup
Seed 42; Adam (lr 1e-3); binary cross-entropy; batch size 64; early stopping on validation PR-AUC (patience 3, best weights restored); class weights computed from the training labels; small grids (see `src/models.py::GRIDS`); hardware: «FILL: CPU/GPU, Colab or local»; training times «FILL».

## 11. Evaluation metrics
Positive class = fraudulent. Accuracy = (TP+TN)/N; Precision = TP/(TP+FP); Recall = TP/(TP+FN); F1 = harmonic mean of precision and recall; ROC-AUC; PR-AUC (average precision). **False positive:** genuine job flagged (lost opportunity, unfair to employer). **False negative:** scam missed (user exposed to harm); recall on fraud is therefore emphasised. Thresholds are tuned on validation (max F1).

## 12. Actual experimental results
Paste the table from `reports/model_comparison.md` (generated by notebook 07 / `python -m src.train`).
«FILL: results table»  ·  Figures: `roc_comparison.png`, `pr_comparison.png`, `cm_<model>.png`, `history_<model>.png`.
Bootstrap intervals for the selected model (notebook 07): «FILL». Calibration observation: «FILL».
*Do not state numbers that are not in your outputs.*

## 13. Model comparison and discussion
Discuss, using your numbers only: baseline vs neural models; effect of BiLSTM vs LSTM; effect of Word2Vec initialisation; precision/recall trade-off; over/under-fitting seen in the curves; uncertainty because of few fraud examples; practical considerations (speed, size, interpretability); final model choice and justification. Selection rule used: highest validation PR-AUC. «FILL»

## 14. Application screenshots
«FILL: Home, Job Analysis (a legitimate-looking example and a scam-like example you wrote yourself), Model Performance, About.»

## 15. Limitations
Dated dataset; strong class imbalance and few fraud test examples; text-only inputs; uncalibrated scores; possible dataset artefacts (company-specific boilerplate); no adversarial robustness; rule-based flags are heuristics; English only; outputs are not proof of fraud.

## 16. Future scope
Newer, multi-source datasets; transformer models (e.g. fine-tuned BERT) and multilingual support; probability calibration; explainability methods such as SHAP/LIME for neural models; company verification features (domain age, registry lookups); human-in-the-loop reporting; monitoring for drift.

## 17. Conclusion
«FILL: 4-6 sentences summarising what was built, the main empirical finding (from your results), and its limits.»

## 18. References
*(Verify details before submission.)*
1. Vidros, S., Kolias, C., Kambourakis, G., Akoglu, L. (2017). Automatic Detection of Online Recruitment Frauds: Characteristics, Methods, and a Public Dataset. *Future Internet*, 9(1), 6.
2. Salton, G., Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. *Information Processing & Management*, 24(5).
3. Mikolov, T., Chen, K., Corrado, G., Dean, J. (2013). Efficient Estimation of Word Representations in Vector Space. arXiv:1301.3781.
4. Hochreiter, S., Schmidhuber, J. (1997). Long Short-Term Memory. *Neural Computation*, 9(8).
5. Schuster, M., Paliwal, K. (1997). Bidirectional recurrent neural networks. *IEEE Trans. Signal Processing*, 45(11).
6. Kim, Y. (2014). Convolutional Neural Networks for Sentence Classification. EMNLP.
7. Rumelhart, D., Hinton, G., Williams, R. (1986). Learning representations by back-propagating errors. *Nature*, 323.
8. Kingma, D., Ba, J. (2015). Adam: A Method for Stochastic Optimization. ICLR (arXiv:1412.6980).
9. Srivastava, N. et al. (2014). Dropout: A Simple Way to Prevent Neural Networks from Overfitting. *JMLR*, 15.
10. Saito, T., Rehmsmeier, M. (2015). The Precision-Recall Plot Is More Informative than the ROC Plot When Evaluating Binary Classifiers on Imbalanced Datasets. *PLoS ONE*, 10(3).
11. Kaggle dataset "Real or Fake Job Posting Prediction" (shivamb).
