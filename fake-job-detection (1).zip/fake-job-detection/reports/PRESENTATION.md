# Presentation outline (12-14 slides, ~10-12 minutes)
1. **Title** - project name, team, subject (NLP + Deep Learning).
2. **Problem** - recruitment scams target students; why detection matters; one anonymised/self-written example.
3. **Objective and scope** - risk estimate, not a verdict; text-based; responsible use.
4. **Dataset (EMSCAD)** - size, columns, target, class imbalance chart *(use your numbers)*, limitations (age).
5. **Pipeline overview** - one architecture diagram: data -> preprocessing -> features -> models -> evaluation -> app.
6. **NLP preprocessing** - normalisation, tokens for URL/e-mail/phone, stop-words but keep negation, stemming vs lemmatisation; raw -> cleaned example.
7. **Representations** - BoW, TF-IDF, n-grams; integer sequences + padding; embeddings/Word2Vec.
8. **Models** - LR/NB baselines, ANN, LSTM/BiLSTM, CNN: small architecture figures.
9. **Deep-learning concepts** - forward/backprop, ReLU/sigmoid, BCE, Adam, dropout (from notebook 04's NumPy demo).
10. **Handling imbalance and leakage** - class weights, PR-AUC, validation-tuned threshold, dedupe before split, fit-on-train-only.
11. **Results** - comparison table + PR curve + confusion matrix of the selected model *(actual numbers)*; honest note on uncertainty.
12. **Error analysis** - what false positives/negatives look like; why recall on fraud matters.
13. **Demo** - Streamlit: a scam-like text and a normal text you wrote; point out the model score vs rule-based flags.
14. **Limitations, future work, responsible use** - dated data, calibration, transformers, verification features. Q&A.
