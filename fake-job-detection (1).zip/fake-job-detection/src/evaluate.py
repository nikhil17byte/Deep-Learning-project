"""Metrics, threshold selection, plots and result aggregation.
Fraudulent = positive class (1). The decision threshold is chosen on the VALIDATION set only;
test data is touched once, for reporting."""
import json

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import (accuracy_score, average_precision_score, confusion_matrix, f1_score,
                             precision_recall_curve, precision_score, recall_score, roc_auc_score, roc_curve)

from . import config as C


def metrics_at(y, p, thr):
    y, p = np.asarray(y), np.asarray(p)
    pred = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {"threshold": float(thr), "accuracy": float(accuracy_score(y, pred)),
            "precision": float(precision_score(y, pred, zero_division=0)),
            "recall": float(recall_score(y, pred, zero_division=0)),
            "f1": float(f1_score(y, pred, zero_division=0)),
            "roc_auc": float(roc_auc_score(y, p)), "pr_auc": float(average_precision_score(y, p)),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


def best_threshold(y, p):
    """Threshold that maximises F1 for the fraud class on the validation set."""
    prec, rec, thr = precision_recall_curve(y, p)
    f1 = 2 * prec[:-1] * rec[:-1] / np.clip(prec[:-1] + rec[:-1], 1e-12, None)
    return float(thr[int(np.argmax(f1))])


def plot_confusion(m, name, path):
    cm = np.array([[m["tn"], m["fp"]], [m["fn"], m["tp"]]])
    fig, ax = plt.subplots(figsize=(4.2, 3.6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=["Legit", "Fraud"], yticklabels=["Legit", "Fraud"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
    ax.set_title(f"{C.MODEL_NAMES.get(name, name)}\n(test set, threshold={m['threshold']:.2f})", fontsize=9)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def plot_history(hist, name, path):
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.4))
    for ax, key in zip(axes, ["loss", "accuracy"]):
        if key in hist:
            ax.plot(hist[key], label="train"); ax.plot(hist.get("val_" + key, []), label="validation")
            ax.set_title(f"{key.capitalize()} - {C.MODEL_NAMES.get(name, name)}", fontsize=10)
            ax.set_xlabel("epoch"); ax.legend()
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def save_result(name, family, y_val, p_val, y_test, p_test, params=None, history=None):
    thr = best_threshold(y_val, p_val)
    res = {"name": name, "display_name": C.MODEL_NAMES.get(name, name), "family": family,
           "threshold": thr, "validation": metrics_at(y_val, p_val, thr),
           "test": metrics_at(y_test, p_test, thr), "test_at_0.5": metrics_at(y_test, p_test, 0.5),
           "params": params or {}, "history": history}
    (C.RESULTS / f"{name}.json").write_text(json.dumps(res, indent=2))
    np.savez_compressed(C.RESULTS / f"{name}_proba.npz", y_val=y_val, p_val=p_val, y_test=y_test, p_test=p_test)
    plot_confusion(res["test"], name, C.FIGS / f"cm_{name}.png")
    if history:
        plot_history(history, name, C.FIGS / f"history_{name}.png")
    return res


def load_results():
    out = [json.loads(p.read_text()) for p in sorted(C.RESULTS.glob("*.json"))]
    order = {n: i for i, n in enumerate(C.ALL_MODELS)}
    return sorted(out, key=lambda r: order.get(r["name"], 99))


def comparison_table(results=None, split="test"):
    results = results or load_results()
    rows = []
    for r in results:
        m = r[split]
        rows.append({"Model": r["display_name"], "Accuracy": m["accuracy"], "Precision": m["precision"],
                     "Recall": m["recall"], "F1": m["f1"], "ROC-AUC": m["roc_auc"], "PR-AUC": m["pr_auc"],
                     "Threshold": m["threshold"], "FP": m["fp"], "FN": m["fn"]})
    return pd.DataFrame(rows)


def aggregate():
    """Collect per-model results, pick the final model on VALIDATION PR-AUC, write summary files."""
    results = load_results()
    if not results:
        raise RuntimeError("No model results found in models/results/. Train a model first.")
    best = max(results, key=lambda r: r["validation"]["pr_auc"])
    (C.MODELS / "metrics.json").write_text(json.dumps(results, indent=2))
    (C.MODELS / "final_model.json").write_text(json.dumps({
        "name": best["name"], "display_name": best["display_name"], "family": best["family"],
        "threshold": best["threshold"],
        "selection_criterion": "highest validation PR-AUC (test set not used for selection)",
        "validation_pr_auc": best["validation"]["pr_auc"]}, indent=2))
    tab = comparison_table(results)
    md = ["| " + " | ".join(tab.columns) + " |", "|" + "---|" * len(tab.columns)]
    for _, r in tab.iterrows():
        md.append("| " + " | ".join(r[c] if isinstance(r[c], str) else (f"{r[c]:.0f}" if c in ("FP", "FN") else f"{r[c]:.3f}")
                                    for c in tab.columns) + " |")
    (C.REPORTS / "model_comparison.md").write_text("\n".join(md) + "\n")
    plot_curves(results)
    return tab, best


def plot_curves(results):
    fig1, ax1 = plt.subplots(figsize=(6, 5)); fig2, ax2 = plt.subplots(figsize=(6, 5))
    for r in results:
        d = np.load(C.RESULTS / f"{r['name']}_proba.npz")
        fpr, tpr, _ = roc_curve(d["y_test"], d["p_test"])
        pr, rc, _ = precision_recall_curve(d["y_test"], d["p_test"])
        ax1.plot(fpr, tpr, label=f"{r['display_name']} (AUC {r['test']['roc_auc']:.3f})")
        ax2.plot(rc, pr, label=f"{r['display_name']} (AP {r['test']['pr_auc']:.3f})")
    ax1.plot([0, 1], [0, 1], "k--", lw=0.8); ax1.set_xlabel("False positive rate"); ax1.set_ylabel("True positive rate")
    ax1.set_title("ROC curves (test set)"); ax1.legend(fontsize=7)
    ax2.set_xlabel("Recall (fraud)"); ax2.set_ylabel("Precision (fraud)"); ax2.set_title("Precision-Recall curves (test set)")
    ax2.legend(fontsize=7)
    fig1.tight_layout(); fig1.savefig(C.FIGS / "roc_comparison.png", dpi=150); plt.close(fig1)
    fig2.tight_layout(); fig2.savefig(C.FIGS / "pr_comparison.png", dpi=150); plt.close(fig2)
