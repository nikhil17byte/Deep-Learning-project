"""Text preprocessing. Two deliberately different pipelines:

* ``clean_for_ml``  - normalise, tokenise, drop stop-words (but KEEP negations), lemmatise.
                      Used for TF-IDF / Bag-of-Words models.
* ``clean_for_nn``  - normalise + tokenise only. Stop-words and word forms are kept because
                      sequence models can learn from word order and function words.

Both keep scam-relevant signals: URLs/e-mails/phones become placeholder tokens (their
*presence* is informative), free-mail domains get their own token, and numbers (salary
amounts) are retained. Fit-on-train-only objects (vocabulary, vectorizers) live elsewhere."""
import html
import json
import re
from collections import Counter
from functools import lru_cache
from pathlib import Path

import numpy as np

FREE_MAIL = {"gmail", "yahoo", "hotmail", "outlook", "aol", "protonmail", "live", "rediffmail", "ymail"}
NEGATIONS = {"no", "nor", "not", "never", "none", "nothing", "neither", "without", "cannot"}
CURRENCY = {"$": " dollar ", "€": " euro ", "£": " pound ", "₹": " rupee "}

EMAIL_RE = re.compile(r"[\w.+-]+@([\w-]+)\.[\w.-]+")
URL_RE = re.compile(r"(https?://\S+|www\.\S+)")
# EMSCAD masks some entities as e.g. "#URL_ab12...#", "#EMAIL_ab12...#", "#PHONE_ab12...#"
MASK_RE = {"url": re.compile(r"#url_\w+#"), "email": re.compile(r"#email_\w+#"), "phone": re.compile(r"#phone_\w+#")}
PHONE_RE = re.compile(r"(?<!\d)(?:\+\d{1,3}[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}(?!\d)|(?<!\d)[6-9]\d{9}(?!\d)")
TOKEN_RE = re.compile(r"[a-z]+(?:'[a-z]+)?|\d+(?:[.,]\d+)*")


def ensure_nltk():
    import nltk
    for path, pkg in [("corpora/stopwords", "stopwords"), ("corpora/wordnet", "wordnet")]:
        try:
            nltk.data.find(path)
        except LookupError:
            nltk.download(pkg, quiet=True)


def normalize_text(text) -> str:
    """Lower-case, strip HTML, replace URLs / e-mails / phones with tokens, keep amounts."""
    t = html.unescape("" if text is None else str(text))
    t = re.sub(r"<[^>]+>", " ", t).replace("\u2019", "'").lower()
    t = MASK_RE["url"].sub(" urltoken ", t)
    t = MASK_RE["email"].sub(" emailtoken ", t)
    t = MASK_RE["phone"].sub(" phonetoken ", t)
    t = EMAIL_RE.sub(lambda m: " freeemailtoken " if m.group(1) in FREE_MAIL else " emailtoken ", t)
    t = URL_RE.sub(" urltoken ", t)
    t = PHONE_RE.sub(" phonetoken ", t)
    for sym, word in CURRENCY.items():
        t = t.replace(sym, word)
    return re.sub(r"\s+", " ", t).strip()


def tokenize(text: str):
    return TOKEN_RE.findall(text)


@lru_cache(maxsize=1)
def stopword_set():
    ensure_nltk()
    from nltk.corpus import stopwords
    return {w for w in stopwords.words("english") if w not in NEGATIONS and "n't" not in w}


@lru_cache(maxsize=1)
def _lemmatizer():
    ensure_nltk()
    from nltk.stem import WordNetLemmatizer
    return WordNetLemmatizer()


@lru_cache(maxsize=1)
def _stemmer():
    from nltk.stem import PorterStemmer
    return PorterStemmer()


@lru_cache(maxsize=200_000)
def lemmatize_word(w: str) -> str:
    if len(w) <= 3:                      # WordNet quirk: "us" -> "u"; short words need no lemmatising
        return w
    lem = _lemmatizer()
    return lem.lemmatize(lem.lemmatize(w, "v"), "n")


@lru_cache(maxsize=200_000)
def stem_word(w: str) -> str:
    return _stemmer().stem(w)


def remove_stopwords(tokens):
    sw = stopword_set()
    return [t for t in tokens if t not in sw]


def clean_for_ml(text) -> str:
    toks = remove_stopwords(tokenize(normalize_text(text)))
    return " ".join(lemmatize_word(t) for t in toks)


def clean_for_nn(text) -> str:
    return " ".join(tokenize(normalize_text(text)))


def compare_stem_lemma(text: str):
    """Return (tokens, stems, lemmas) for the same text - used in the NLP notebook."""
    toks = remove_stopwords(tokenize(normalize_text(text)))
    return toks, [stem_word(t) for t in toks], [lemmatize_word(t) for t in toks]


class Vocabulary:
    """Word -> integer index. 0 = padding, 1 = out-of-vocabulary. Built on TRAIN data only."""
    PAD, OOV = "<pad>", "<oov>"

    def __init__(self, token_to_id=None):
        self.token_to_id = token_to_id or {self.PAD: 0, self.OOV: 1}

    @classmethod
    def build(cls, docs, max_size=20000, min_freq=2):
        counts = Counter(t for d in docs for t in d)
        vocab = cls()
        for tok, c in counts.most_common(max_size - 2):
            if c >= min_freq:
                vocab.token_to_id[tok] = len(vocab.token_to_id)
        return vocab

    def __len__(self):
        return len(self.token_to_id)

    def encode(self, tokens, max_len):
        ids = [self.token_to_id.get(t, 1) for t in tokens[:max_len]]
        return ids + [0] * (max_len - len(ids))          # post-padding (masked in the LSTM)

    def encode_many(self, docs, max_len):
        return np.array([self.encode(d, max_len) for d in docs], dtype="int32")

    def save(self, path):
        Path(path).write_text(json.dumps(self.token_to_id))

    @classmethod
    def load(cls, path):
        return cls(json.loads(Path(path).read_text()))
