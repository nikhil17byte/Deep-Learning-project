"""Inference. Loads the artefacts saved by training (never trains) and applies exactly the same
preprocessing as in training.

    from src.predict import predict_job
    predict_job(description="...", title="...", company="...")
"""
import json
from pathlib import Path

import joblib
import numpy as np

from . import config as C
from .data import combine_fields
from .explain import find_red_flags, linear_top_terms
from .preprocessing import Vocabulary, clean_for_ml, clean_for_nn

DISCLAIMER = ("This is an AI-generated risk estimate based on patterns in an older public dataset (EMSCAD). "
              "It is NOT proof that a job is fraudulent or legitimate. Always verify the employer independently.")


class FakeJobPredictor:
    def __init__(self, model_dir=C.MODELS):
        self.dir = Path(model_dir)
        f = self.dir / "final_model.json"
        if not f.exists():
            raise FileNotFoundError("No trained model found. Run `python -m src.train` first (see README).")
        info = json.loads(f.read_text())
        self.name, self.display_name, self.family = info["name"], info["display_name"], info["family"]
        self.threshold = float(info["threshold"])
        self._tfidf = self._lr = None
        if (self.dir / "tfidf.joblib").exists() and (self.dir / "logreg_tfidf.joblib").exists():
            self._tfidf = joblib.load(self.dir / "tfidf.joblib"); self._lr = joblib.load(self.dir / "logreg_tfidf.joblib")
        if self.name == "logreg_tfidf":
            self.model = self._lr
        elif self.name == "nb_bow":
            self.vec, self.model = joblib.load(self.dir / "bow.joblib"), joblib.load(self.dir / "nb_bow.joblib")
        else:
            from tensorflow import keras
            self.model = keras.models.load_model(self.dir / f"{self.name}.keras")
            if self.name != "ann_tfidf":
                self.vocab = Vocabulary.load(self.dir / "vocab.json")

    def score(self, text: str) -> float:
        """Model output for the fraudulent class (0-1). Not a calibrated probability."""
        if self.name == "logreg_tfidf":
            return float(self.model.predict_proba(self._tfidf.transform([clean_for_ml(text)]))[0, 1])
        if self.name == "nb_bow":
            return float(self.model.predict_proba(self.vec.transform([clean_for_ml(text)]))[0, 1])
        if self.name == "ann_tfidf":
            x = self._tfidf.transform([clean_for_ml(text)]).toarray().astype("float32")
            return float(self.model.predict(x, verbose=0)[0, 0])
        ids = self.vocab.encode_many([clean_for_nn(text).split()], C.MAX_LEN)
        return float(self.model.predict(ids, verbose=0)[0, 0])

    def predict(self, description, title="", company="", location="", salary="", employment_type=""):
        rec = {"title": title, "company_profile": f"company {company}" if company else "", "description": description,
               "location": location, "salary_range": salary, "employment_type": employment_type}
        text = combine_fields(rec)
        if len(description.strip()) < 20:
            raise ValueError("Please provide a longer job description.")
        s = self.score(text)
        label_id = int(s >= self.threshold)
        side = "above" if label_id else "below"
        explanation = (f"The {self.display_name} model gave this posting a score of {s:.0%} for the fraudulent class, "
                       f"which is {side} its decision threshold ({self.threshold:.0%}). The score reflects how similar the wording "
                       "is to postings labelled fraudulent in the training data; it is not a verified probability.")
        terms = None
        if self._tfidf is not None and self._lr is not None:
            terms = linear_top_terms(clean_for_ml(text), self._tfidf, self._lr)
        return {"label_id": label_id, "label": C.LABELS[label_id], "score": s, "threshold": self.threshold,
                "model": self.display_name, "explanation": explanation,
                "red_flags": find_red_flags(text),          # rule-based, independent of the model
                "logreg_terms": terms,                      # explains the logistic-regression baseline only
                "disclaimer": DISCLAIMER}


_PREDICTOR = None

def predict_job(description, **fields):
    """Reusable entry point (lazy-loads and caches the predictor)."""
    global _PREDICTOR
    if _PREDICTOR is None:
        _PREDICTOR = FakeJobPredictor()
    return _PREDICTOR.predict(description, **fields)
