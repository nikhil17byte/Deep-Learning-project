"""Loading, de-duplication and leakage-safe splitting of the EMSCAD dataset."""
import json

import pandas as pd
from sklearn.model_selection import train_test_split

from . import config as C
from .preprocessing import clean_for_ml, clean_for_nn


def combine_fields(rec: dict) -> str:
    """Build ONE text string from the posting fields. Used identically for training rows and for
    new postings at inference time, so both see the same kind of input."""
    def g(k):
        v = rec.get(k, "")
        return "" if v is None or (isinstance(v, float) and pd.isna(v)) else str(v).strip()
    parts = [g("title"),
             f"employment type {g('employment_type')}" if g("employment_type") else "",
             f"location {g('location')}" if g("location") else "",
             f"salary {g('salary_range')}" if g("salary_range") else "",
             g("company_profile"), g("description"), g("requirements"), g("benefits")]
    return ". ".join(p for p in parts if p)


def load_raw(path=None) -> pd.DataFrame:
    path = path or C.DATA_RAW
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}.\nDownload 'fake_job_postings.csv' from Kaggle "
            "(shivamb/real-or-fake-fake-jobposting-prediction) and place it there.")
    df = pd.read_csv(path)
    missing = [c for c in C.REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing expected columns: {missing}")
    return df


def build_splits(df: pd.DataFrame):
    """De-duplicate (before splitting!), then stratified 70/15/15 split with a fixed seed."""
    info = {"raw_shape": list(df.shape),
            "raw_class_counts": {int(k): int(v) for k, v in df[C.TARGET].value_counts().sort_index().items()}}
    df = df.copy()
    df["text"] = df.apply(lambda r: combine_fields(r.to_dict()), axis=1)
    conflict = df.groupby("text")[C.TARGET].transform("nunique") > 1
    info["dropped_label_conflicts"] = int(conflict.sum())
    df = df[~conflict]
    n = len(df)
    df = df.drop_duplicates("text")
    info["dropped_duplicates"] = int(n - len(df))
    info["after_cleaning_class_counts"] = {int(k): int(v) for k, v in df[C.TARGET].value_counts().sort_index().items()}

    train, temp = train_test_split(df, test_size=0.30, stratify=df[C.TARGET], random_state=C.SEED)
    val, test = train_test_split(temp, test_size=0.50, stratify=temp[C.TARGET], random_state=C.SEED)
    splits = {}
    for name, part in [("train", train), ("val", val), ("test", test)]:
        cols = (["job_id"] if "job_id" in part else []) + ["text", C.TARGET]
        part = part[cols].copy()
        part["ml_text"] = part["text"].map(clean_for_ml)
        part["nn_text"] = part["text"].map(clean_for_nn)
        part.to_csv(C.PROCESSED / f"{name}.csv", index=False)
        splits[name] = part.reset_index(drop=True)
        info[f"{name}_class_counts"] = {int(k): int(v) for k, v in part[C.TARGET].value_counts().sort_index().items()}
    (C.REPORTS / "dataset_info.json").write_text(json.dumps(info, indent=2))
    return splits


def get_splits(rebuild=False, path=None):
    files = [C.PROCESSED / f"{s}.csv" for s in ("train", "val", "test")]
    if not rebuild and all(f.exists() for f in files):
        return {s: pd.read_csv(f).fillna("") for s, f in zip(("train", "val", "test"), files)}
    return build_splits(load_raw(path))
