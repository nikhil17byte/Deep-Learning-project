"""Two DIFFERENT kinds of explanation - kept separate on purpose:

1. ``find_red_flags``  - rule-based regex checks for well-known scam patterns. These are
   heuristics that are independent of the trained model. They do NOT explain the model score.
2. ``linear_top_terms`` - for the logistic-regression baseline only: coefficient x TF-IDF value
   for each term in the posting. This is a genuine (linear) explanation of THAT model's score."""
import re

RED_FLAGS = [
    ("Upfront payment requested",
     r"(registration|training|processing|security|application|admin\w*|starter kit|equipment)\s+(fee|deposit|payment|cost)"
     r"|pay\s+(a|an|the)?\s*(small\s+)?(fee|deposit)|wire transfer|western union|money ?gram|gift cards?|send (us )?money",
     "Legitimate employers do not ask applicants to pay fees or send money."),
    ("Contact through a messaging app",
     r"whats ?app|telegram|signal app|hangouts|text (us|me) at|skype id",
     "Scam recruiters often move conversations to private messaging apps."),
    ("Free e-mail address for company contact",
     r"[\w.+-]+@(gmail|yahoo|hotmail|outlook|aol|protonmail|ymail|rediffmail)\.\w+",
     "Companies normally use an e-mail address on their own domain."),
    ("Unrealistic or vague earnings",
     r"earn\s+(up to\s+)?[$€£₹]?\s?\d[\d,]*\s*(\+)?\s*(per|a|/)\s*(day|week|hour)|easy money|guaranteed (income|salary|pay)|get rich|unlimited earning",
     "Very high or guaranteed pay for little work is a common lure."),
    ("'No experience needed' language",
     r"no (prior )?(experience|skills?|qualifications?|degree) (is )?(needed|required|necessary)|anyone can apply|no interview",
     "Not conclusive alone, but frequently used to attract many victims."),
    ("Urgency / pressure",
     r"urgent(ly)? (hiring|required|need)|apply (immediately|now|today)|limited (seats|positions|vacancies)|hurry",
     "Pressure to act quickly discourages careful checking."),
    ("Early request for sensitive information",
     r"social security|\bssn\b|bank (account|details)|credit card|passport (copy|scan)|aadhaar|date of birth and",
     "Personal or financial details should not be required to apply."),
]


def find_red_flags(text, min_words=40):
    flags = []
    for name, pattern, why in RED_FLAGS:
        m = re.search(pattern, text, flags=re.I)
        if m:
            flags.append({"flag": name, "matched_text": m.group(0).strip()[:80], "why": why})
    if len(text.split()) < min_words:
        flags.append({"flag": "Very little information", "matched_text": f"{len(text.split())} words",
                      "why": "Very short postings give little to verify; legitimate ads usually describe the role and company."})
    return flags


def linear_top_terms(clean_text, tfidf, lr, k=8):
    """Terms in this posting that pushed the logistic-regression score towards 'fraudulent'."""
    X = tfidf.transform([clean_text]).tocoo()
    names = tfidf.get_feature_names_out()
    contrib = [(names[j], float(v * lr.coef_[0][j])) for j, v in zip(X.col, X.data)]
    up = sorted([c for c in contrib if c[1] > 0], key=lambda c: -c[1])[:k]
    down = sorted([c for c in contrib if c[1] < 0], key=lambda c: c[1])[:k]
    return {"towards_fraud": up, "towards_legitimate": down}
