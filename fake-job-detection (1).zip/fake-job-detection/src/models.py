"""Model definitions and training routines (baselines, ANN, LSTM, BiLSTM, CNN, LSTM+Word2Vec).
TensorFlow is imported lazily so the baselines and the web app work without it where possible."""
import time

import joblib
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.naive_bayes import MultinomialNB
from sklearn.utils.class_weight import compute_class_weight

from . import config as C
from .evaluate import save_result
from .preprocessing import Vocabulary

# --------------------------------------------------------------------------- baselines
def train_baselines(splits):
    tr, va, te = splits["train"], splits["val"], splits["test"]
    ytr, yva, yte = (d[C.TARGET].values for d in (tr, va, te))
    out = {}

    # Logistic Regression on TF-IDF (unigrams + bigrams). Vectoriser is fitted on TRAIN only.
    tfidf = TfidfVectorizer(ngram_range=(1, 2), max_features=C.TFIDF_FEATURES, min_df=2, sublinear_tf=True)
    Xtr = tfidf.fit_transform(tr.ml_text); Xva = tfidf.transform(va.ml_text); Xte = tfidf.transform(te.ml_text)
    tuning, best = [], None
    for c in [0.1, 0.3, 1, 3, 10, 30]:
        m = LogisticRegression(C=c, class_weight="balanced", max_iter=2000, solver="liblinear", random_state=C.SEED)
        m.fit(Xtr, ytr)
        ap = average_precision_score(yva, m.predict_proba(Xva)[:, 1])
        tuning.append({"C": c, "val_pr_auc": float(ap)})
        if best is None or ap > best[0]:
            best = (ap, m, c)
    _, lr, c = best
    joblib.dump(tfidf, C.MODELS / "tfidf.joblib"); joblib.dump(lr, C.MODELS / "logreg_tfidf.joblib")
    out["logreg_tfidf"] = save_result("logreg_tfidf", "sklearn", yva, lr.predict_proba(Xva)[:, 1], yte,
                                      lr.predict_proba(Xte)[:, 1],
                                      {"best_C": c, "class_weight": "balanced", "tuning": tuning,
                                       "n_features": int(Xtr.shape[1])})

    # Multinomial Naive Bayes on Bag-of-Words counts
    bow = CountVectorizer(ngram_range=(1, 2), max_features=C.TFIDF_FEATURES, min_df=2)
    Btr = bow.fit_transform(tr.ml_text); Bva = bow.transform(va.ml_text); Bte = bow.transform(te.ml_text)
    tuning, best = [], None
    for a in [0.01, 0.1, 0.5, 1.0]:
        m = MultinomialNB(alpha=a).fit(Btr, ytr)
        ap = average_precision_score(yva, m.predict_proba(Bva)[:, 1])
        tuning.append({"alpha": a, "val_pr_auc": float(ap)})
        if best is None or ap > best[0]:
            best = (ap, m, a)
    _, nb, a = best
    joblib.dump(bow, C.MODELS / "bow.joblib"); joblib.dump(nb, C.MODELS / "nb_bow.joblib")
    out["nb_bow"] = save_result("nb_bow", "sklearn", yva, nb.predict_proba(Bva)[:, 1], yte,
                                nb.predict_proba(Bte)[:, 1], {"best_alpha": a, "tuning": tuning})
    return out


# --------------------------------------------------------------------------- data for NNs
_SEQ = {}

def get_sequences(splits):
    """Vocabulary (train only) + padded integer sequences for every split."""
    if "X" not in _SEQ:
        docs = {s: [t.split() for t in d.nn_text] for s, d in splits.items()}
        vocab = Vocabulary.build(docs["train"], C.MAX_VOCAB, min_freq=2)
        vocab.save(C.MODELS / "vocab.json")
        _SEQ["vocab"] = vocab
        _SEQ["docs"] = docs
        _SEQ["X"] = {s: vocab.encode_many(d, C.MAX_LEN) for s, d in docs.items()}
    return _SEQ["vocab"], _SEQ["X"]


def sparse_dataset(X, y=None, batch=64, shuffle=False, repeat=False):
    """Stream a sparse TF-IDF matrix to Keras in dense mini-batches (avoids a huge dense array)."""
    import tensorflow as tf
    n, d = X.shape
    state = {"epoch": 0}

    def gen():
        idx = np.arange(n)
        if shuffle:
            np.random.default_rng(C.SEED + state["epoch"]).shuffle(idx); state["epoch"] += 1
        for s in range(0, n, batch):
            b = idx[s:s + batch]
            xb = X[b].toarray().astype("float32")
            yield xb if y is None else (xb, y[b].astype("float32"))
    xs = tf.TensorSpec((None, d), tf.float32)
    sig = xs if y is None else (xs, tf.TensorSpec((None,), tf.float32))
    ds = tf.data.Dataset.from_generator(gen, output_signature=sig)
    return (ds.repeat() if repeat else ds).prefetch(2)


def _compile(model, lr):
    from tensorflow import keras
    model.compile(optimizer=keras.optimizers.Adam(lr), loss="binary_crossentropy",
                  metrics=["accuracy", keras.metrics.AUC(name="auc"), keras.metrics.AUC(curve="PR", name="pr_auc")])
    return model


# --------------------------------------------------------------------------- architectures
def build_ann(input_dim, units=(128, 64), dropout=0.4, l2=1e-5, lr=1e-3):
    """Feed-forward net: Input -> Dense(ReLU) -> Dropout -> Dense(ReLU) -> Dropout -> Dense(sigmoid)."""
    from tensorflow import keras
    from tensorflow.keras import layers, regularizers
    reg = regularizers.l2(l2)
    m = keras.Sequential([layers.Input((input_dim,)),
                          layers.Dense(units[0], activation="relu", kernel_regularizer=reg, name="hidden_1"),
                          layers.Dropout(dropout),
                          layers.Dense(units[1], activation="relu", kernel_regularizer=reg, name="hidden_2"),
                          layers.Dropout(dropout),
                          layers.Dense(1, activation="sigmoid", name="output")], name="ann")
    return _compile(m, lr)


def build_lstm(vocab_size, max_len=C.MAX_LEN, emb_dim=C.EMB_DIM, units=64, dropout=0.3, lr=1e-3,
               bidirectional=False, emb_matrix=None):
    """Embedding -> (Bi)LSTM -> Dropout -> Dense(sigmoid). Padding is masked."""
    from tensorflow import keras
    from tensorflow.keras import layers
    init = keras.initializers.Constant(emb_matrix) if emb_matrix is not None else "uniform"
    rnn = layers.LSTM(units)
    m = keras.Sequential([layers.Input((max_len,), dtype="int32"),
                          layers.Embedding(vocab_size, emb_dim, embeddings_initializer=init, mask_zero=True, name="embedding"),
                          layers.Dropout(dropout),
                          layers.Bidirectional(rnn) if bidirectional else rnn,
                          layers.Dropout(dropout),
                          layers.Dense(1, activation="sigmoid", name="output")],
                         name="bilstm" if bidirectional else "lstm")
    return _compile(m, lr)


def build_cnn(vocab_size, max_len=C.MAX_LEN, emb_dim=C.EMB_DIM, filters=128, kernel_size=3, dropout=0.4, lr=1e-3):
    """Embedding -> Conv1D(stride 1, 'same' padding) -> GlobalMaxPool -> Dense -> Dense(sigmoid)."""
    from tensorflow import keras
    from tensorflow.keras import layers
    m = keras.Sequential([layers.Input((max_len,), dtype="int32"),
                          layers.Embedding(vocab_size, emb_dim, name="embedding"),
                          layers.Conv1D(filters, kernel_size, strides=1, padding="same", activation="relu", name="conv1d"),
                          layers.GlobalMaxPooling1D(),
                          layers.Dropout(dropout),
                          layers.Dense(64, activation="relu"),
                          layers.Dropout(dropout),
                          layers.Dense(1, activation="sigmoid", name="output")], name="cnn")
    return _compile(m, lr)


def build_w2v_matrix(train_docs, vocab, dim=C.EMB_DIM):
    """Train Word2Vec (skip-gram) on TRAIN text only and align it with our vocabulary."""
    from gensim.models import Word2Vec
    w2v = Word2Vec(sentences=train_docs, vector_size=dim, window=5, min_count=2, sg=1, workers=1,
                   epochs=10, seed=C.SEED)
    mat = np.random.default_rng(C.SEED).normal(0, 0.05, (len(vocab), dim)).astype("float32")
    mat[0] = 0
    hits = 0
    for tok, i in vocab.token_to_id.items():
        if tok in w2v.wv:
            mat[i] = w2v.wv[tok]; hits += 1
    return mat, hits / len(vocab), w2v


GRIDS = {
    "ann_tfidf": [dict(units=(128, 64), dropout=0.4), dict(units=(256, 128), dropout=0.5)],
    "lstm": [dict(units=64, dropout=0.3), dict(units=128, dropout=0.5)],
    "bilstm": [dict(units=64, dropout=0.3), dict(units=128, dropout=0.5)],
    "cnn": [dict(filters=128, kernel_size=3), dict(filters=128, kernel_size=5)],
    "lstm_w2v": [dict(units=64, dropout=0.3)],
}
EPOCHS = {"ann_tfidf": 15, "lstm": 10, "bilstm": 10, "cnn": 10, "lstm_w2v": 10}


def class_weights(y):
    w = compute_class_weight("balanced", classes=np.array([0, 1]), y=y)
    return {0: float(w[0]), 1: float(w[1])}


def train_nn_model(name, splits, quick=False, tune=True, patience=3):
    """Train one neural model, choosing hyper-parameters on validation PR-AUC. Returns result dict."""
    from tensorflow import keras
    ytr, yva, yte = (splits[s][C.TARGET].values for s in ("train", "val", "test"))
    cw = class_weights(ytr)
    epochs = 2 if quick else EPOCHS[name]
    grid = GRIDS[name] if tune and not quick else GRIDS[name][:1]
    extra = {}

    if name == "ann_tfidf":
        tfidf = joblib.load(C.MODELS / "tfidf.joblib") if (C.MODELS / "tfidf.joblib").exists() else None
        if tfidf is None:
            raise RuntimeError("Run the baseline step first: it fits the TF-IDF vectoriser used by the ANN.")
        Xs = {s: tfidf.transform(splits[s].ml_text) for s in ("train", "val", "test")}
        build = lambda cfg: build_ann(Xs["train"].shape[1], **cfg)
        steps = lambda n, b: int(np.ceil(n / b))
        fit = lambda m, cb: m.fit(sparse_dataset(Xs["train"], ytr, 64, True, repeat=True), steps_per_epoch=steps(len(ytr), 64),
                                  validation_data=sparse_dataset(Xs["val"], yva, 256, repeat=True),
                                  validation_steps=steps(len(yva), 256), epochs=epochs, callbacks=cb,
                                  class_weight=cw, shuffle=False, verbose=2)
        predict = lambda m, s: np.concatenate([m.predict(Xs[s][i:i + 256].toarray().astype("float32"), verbose=0).ravel()
                                               for i in range(0, Xs[s].shape[0], 256)])
    else:
        vocab, X = get_sequences(splits)
        emb = None
        if name == "lstm_w2v":
            emb, coverage, _ = build_w2v_matrix(_SEQ["docs"]["train"], vocab)
            extra["word2vec_vocab_coverage"] = float(coverage)
        builders = {"lstm": lambda cfg: build_lstm(len(vocab), **cfg),
                    "bilstm": lambda cfg: build_lstm(len(vocab), bidirectional=True, **cfg),
                    "cnn": lambda cfg: build_cnn(len(vocab), **cfg),
                    "lstm_w2v": lambda cfg: build_lstm(len(vocab), emb_matrix=emb, **cfg)}
        build = builders[name]
        fit = lambda m, cb: m.fit(X["train"], ytr, validation_data=(X["val"], yva), batch_size=64, epochs=epochs,
                                  callbacks=cb, class_weight=cw, verbose=2)
        predict = lambda m, s: m.predict(X[s], batch_size=256, verbose=0).ravel()

    best, tuning = None, []
    for cfg in grid:
        keras.utils.set_random_seed(C.SEED)
        model = build(cfg)
        cb = [keras.callbacks.EarlyStopping(monitor="val_pr_auc", mode="max", patience=patience, restore_best_weights=True)]
        t0 = time.time()
        hist = fit(model, cb).history
        p_val = predict(model, "val")
        ap = float(average_precision_score(yva, p_val))
        tuning.append({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in cfg.items()},
                       "val_pr_auc": ap, "epochs_run": len(hist["loss"]), "seconds": round(time.time() - t0)})
        if best is None or ap > best["ap"]:
            best = dict(ap=ap, model=model, hist=hist, cfg=cfg, p_val=p_val)

    model = best["model"]
    p_test = predict(model, "test")
    model.save(C.MODELS / f"{name}.keras")
    hist = {k: [float(x) for x in v] for k, v in best["hist"].items()}
    params = {"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in best["cfg"].items()},
              "tuning": tuning, "class_weight": cw, "n_parameters": int(model.count_params()),
              "max_epochs": epochs, "quick_mode": quick, **extra}
    return save_result(name, "keras", yva, best["p_val"], yte, p_test, params, hist)
