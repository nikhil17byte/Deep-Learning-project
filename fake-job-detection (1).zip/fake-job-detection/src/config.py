"""Central configuration. Every module imports paths, labels and hyper-parameters from here
so training, evaluation and deployment always agree."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_RAW = ROOT / "data" / "raw" / "fake_job_postings.csv"
PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"
RESULTS = MODELS / "results"
FIGS = ROOT / "reports" / "figures"
REPORTS = ROOT / "reports"

SEED = 42
TARGET = "fraudulent"

# One label mapping used everywhere. Fraudulent is the POSITIVE class (1).
LABELS = {0: "Likely Legitimate", 1: "Potentially Fraudulent"}
LABEL_TO_ID = {"legitimate": 0, "fraudulent": 1}

REQUIRED_COLUMNS = ["title", "location", "salary_range", "employment_type", "company_profile",
                    "description", "requirements", "benefits", TARGET]

# Features / sequence settings
TFIDF_FEATURES = 20000
MAX_VOCAB = 20000
MAX_LEN = 300
EMB_DIM = 100

MODEL_NAMES = {
    "logreg_tfidf": "Logistic Regression (TF-IDF)",
    "nb_bow": "Multinomial NB (Bag-of-Words)",
    "ann_tfidf": "ANN (TF-IDF)",
    "lstm": "LSTM",
    "bilstm": "BiLSTM",
    "cnn": "1D CNN",
    "lstm_w2v": "LSTM + Word2Vec init",
}
NN_MODELS = ["ann_tfidf", "lstm", "bilstm", "cnn", "lstm_w2v"]
ALL_MODELS = ["logreg_tfidf", "nb_bow"] + NN_MODELS

for _d in (PROCESSED, MODELS, RESULTS, FIGS):
    _d.mkdir(parents=True, exist_ok=True)
