"""Train everything from the command line.

    python -m src.train                      # all models, with small hyper-parameter search
    python -m src.train --models logreg_tfidf nb_bow ann_tfidf
    python -m src.train --quick              # 2 epochs, no tuning (smoke test only)
    python -m src.train --rebuild-data       # redo cleaning + splits
"""
import argparse
import json

from . import config as C
from .data import get_splits
from .evaluate import aggregate
from .models import get_sequences, train_baselines, train_nn_model


def write_preprocess_config(splits):
    cfg = {"seed": C.SEED, "labels": {str(k): v for k, v in C.LABELS.items()}, "positive_class": "fraudulent (1)",
           "max_len": C.MAX_LEN, "max_vocab": C.MAX_VOCAB, "tfidf_features": C.TFIDF_FEATURES,
           "split": "70/15/15 stratified, de-duplicated before splitting",
           "ml_pipeline": "normalise -> regex tokenise -> stop-words removed (negations kept) -> WordNet lemmatise",
           "nn_pipeline": "normalise -> regex tokenise (stop-words kept) -> integer ids -> post-pad/truncate",
           "n_train": len(splits["train"]), "n_val": len(splits["val"]), "n_test": len(splits["test"])}
    (C.MODELS / "preprocess_config.json").write_text(json.dumps(cfg, indent=2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", default=["all"], choices=["all"] + C.ALL_MODELS)
    ap.add_argument("--quick", action="store_true", help="2 epochs, no tuning (smoke test)")
    ap.add_argument("--no-tune", action="store_true")
    ap.add_argument("--rebuild-data", action="store_true")
    args = ap.parse_args()

    splits = get_splits(rebuild=args.rebuild_data)
    write_preprocess_config(splits)
    chosen = C.ALL_MODELS if "all" in args.models else args.models
    print({k: len(v) for k, v in splits.items()})

    if "logreg_tfidf" in chosen or "nb_bow" in chosen or not (C.MODELS / "tfidf.joblib").exists():
        print("== Baselines =="); train_baselines(splits)
    get_sequences(splits) if any(m in C.NN_MODELS for m in chosen) else None
    for name in [m for m in C.NN_MODELS if m in chosen]:
        print(f"== {name} =="); train_nn_model(name, splits, quick=args.quick, tune=not args.no_tune)

    table, best = aggregate()
    print(table.round(3).to_string(index=False))
    print(f"\nSelected on validation PR-AUC: {best['display_name']}")


if __name__ == "__main__":
    main()
